package com.example.headtohead;

import android.content.Context;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ClassicGameFBmodule {

    private Context context;
    private FirebaseDatabase firebaseDatabase;

    public ClassicGameFBmodule(Context context) {
        this.context = context;
        firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference Players = firebaseDatabase.getReference("ClassicGameControl/playerswaiting");
        DatabaseReference AnswerStatusP1 = firebaseDatabase.getReference("ClassicGameControl/answerStatus/p1");
        DatabaseReference AnswerStatusP2 = firebaseDatabase.getReference("ClassicGameControl/answerStatus/p2");
        DatabaseReference CurrentQuestion = firebaseDatabase.getReference("ClassicGameControl/CurrentQuestion");
        CurrentQuestion.setValue("");
        AnswerStatusP1.setValue(null);
        AnswerStatusP2.setValue(null);


    }

    public void ClassicSetPlayers(GameActivityClassic gameActivityClassic) {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ClassicGameControl/playerswaiting");

        reference.addListenerForSingleValueEvent(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Boolean isWaiting = dataSnapshot.getValue(Boolean.class);
                if (isWaiting == false) {
                    reference.setValue(true);
                    gameActivityClassic.StratingPoint(1);
                } else if (isWaiting == true) {
                    reference.setValue(false);
                    gameActivityClassic.StratingPoint(2);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}