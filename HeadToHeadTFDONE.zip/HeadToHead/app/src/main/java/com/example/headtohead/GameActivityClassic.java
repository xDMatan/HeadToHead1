package com.example.headtohead;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.headtohead.question.ClassicQuestion;
import com.example.headtohead.question.GameCollections;

import java.util.ArrayList;
import java.util.HashMap;

public class GameActivityClassic extends AppCompatActivity implements View.OnClickListener {
    private GameCollections collections;
    private EditText etAnwser;
    private ImageButton ibSend;
    private ClassicGameFBmodule fBmodule;
    private ClassicQuestion CurrentQuestion;
    private int player;
    private TextView tvQuestion;

    private ArrayList<ClassicQuestion> classicCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_classic);
        collections = new GameCollections();
        classicCollection = collections.getClassisCollection();
        etAnwser = findViewById(R.id.etAnwser);
        ibSend = findViewById(R.id.ibSendAnswer);
        ibSend.setOnClickListener(this);
        tvQuestion = findViewById(R.id.TvQuestion);
        fBmodule = new ClassicGameFBmodule(this);
        fBmodule.ClassicSetPlayers(this);
        CurrentQuestion = new ClassicQuestion("","",new HashMap<>(),false);


    }

    public void StratingPoint(int player) {
        this.player = player;


        if (this.player == 1) {
            tvQuestion.setText("Waiting for Players");
        }
        if (this.player == 2) {
            tvQuestion.setText("Waiting...");
        }
    }

    @Override
    public void onClick(View v) {
        if (v == ibSend) {

        }
    }

    public void GetANewRandomQuestionForP2() {
            Boolean valid = false;
            String CurrentType = CurrentQuestion.getTypeofquestion();
            while (!valid) {
                java.util.Collections.shuffle(this.classicCollection);
                this.CurrentQuestion = classicCollection.get(0);
                if (CurrentType.equals(CurrentQuestion.getTypeofquestion()) == false && CurrentQuestion.getWaseverused() == false) {
                    classicCollection.get(0).setWaseverused(true);
                    valid = true;
                }


        }

    }
}